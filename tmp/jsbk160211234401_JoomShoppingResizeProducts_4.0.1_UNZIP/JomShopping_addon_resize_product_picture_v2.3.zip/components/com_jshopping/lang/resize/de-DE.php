<?php
/**
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
//resize jshop pictures
define('_JSHOP_RESIZE', "Resize Bild");
define('_JSHOP_LABEL_TITTLE', 'Resize thumbspicture und die Bildwiedergabe für alle JoomShopping Produkte ');  
define('_JSHOP_LABEL_DESCRIPTION', 'Bitte, geduldig zu sein, nicht in der Nähe eines Fensters Ihres Browsers und nicht neu laden Seite nach einem Klick auf die Schaltfläche Start Resize.');  
define('_JSHOP_RESIZE_BUTTON', 'Start Resize');  
?>