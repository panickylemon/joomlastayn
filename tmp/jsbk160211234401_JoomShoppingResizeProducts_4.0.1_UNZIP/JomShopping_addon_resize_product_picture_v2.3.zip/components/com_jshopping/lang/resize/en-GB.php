<?php
/**
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

//resize jshop pictures  
define('_JSHOP_RESIZE', 'Resize picture');  
define('_JSHOP_LABEL_TITTLE', 'Resize thumbspicture and viewing picture for all JoomShopping products ');  
define('_JSHOP_LABEL_DESCRIPTION', 'Please, be patient, do not close a window of your browser and do not reload page after clicking on the button Start Resize.');  
define('_JSHOP_RESIZE_BUTTON', 'Start Resize'); 
?>