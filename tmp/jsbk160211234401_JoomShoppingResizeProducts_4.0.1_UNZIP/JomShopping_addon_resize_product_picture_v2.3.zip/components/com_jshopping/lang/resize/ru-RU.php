<?php
/**
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

//resize jshop pictures  
define('_JSHOP_RESIZE', "Изменение размера фотографий");
define('_JSHOP_LABEL_TITTLE', 'Изменение размера thumbspicture и viewing picture для всех продуктов JoomShopping ');  
define('_JSHOP_LABEL_DESCRIPTION', 'Пожалуйста, будьте терпеливы, не закрывайте окно браузера и не перезагружайте страницу после нажатия на кнопку Начать изменение размеа.');  
define('_JSHOP_RESIZE_BUTTON', 'Начать изменение размера');    
?>